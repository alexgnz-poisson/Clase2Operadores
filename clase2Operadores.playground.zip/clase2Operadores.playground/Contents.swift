import UIKit

let numero1  = 7
let numero2 = 11

let suma = numero1 + numero2
//print(suma)
let mult = numero1*numero2
let div = numero2-numero1
//Operadores de comparacion
let comp1 = numero1 == numero2
let comp2 = numero1<numero2
let comp3 = numero1>numero2

//Arreglos
var numeros: [Int] = [6,1, 22, 12, 4, 5,7]
let cantNumero = numeros.count
var ordenados = numeros.sorted()

numeros.append(123)
numeros.append(200)
numeros.remove(at: 2)

//Condiciones
let a = 4
let b = 3

if(a>b){
    print("A es mas grande que B")
}
//Operador ternario
let edad = 23
let result = edad > 21 ? "Es mayor que 21" : "No es mayor que 21"
print(result)

//if else if
let num1 = 3
let num2 = -4

if num1 > 0  {
    print("El numero es positivo")
} else if num1 < 0{
    print("El numero es negativo")
} else {
    print("El numero es cero")
}


if num2 > 0  {
    print("El numero es positivo")
} else if num2 < 0{
    print("El numero es negativo")
} else {
    print("El numero es cero")
}

//Switch
let clima = "lloviendo"
switch clima {
case "Soleado","soleado":
    print("Es agradable")
case "Nublado","nublado":
    print("No es agradable")
case "Lloviendo","lloviendo":
    print("NO es agradable")
default:
    print("No existe ese clima")
}













